# The source version file is <proj>/mercury/version.py, anything else is auto generated.
__version__ = '3.2.7'